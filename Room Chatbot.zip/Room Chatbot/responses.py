def handle_response(message) -> str:
    p_message = message.upper()
    print(p_message)
    

    room_directory = {"AAS" : ["African-American Studies" , "138 Mountfort Street"], "AGG": ["Agganis Arena" , "925 Commonwealth Avenue"], "ASC" : ["Academic Support Center", "300 Babcock Street"], "BAB" : ["Babcock Street", "300 Babcock Street"],
                      "BRB" : ["Biology Research Building", "5 Cummington Mall"], "BSC" : ["Biological Science Center", "2 Cummington Mall"], "CAS" : ["College of Arts & Sciences", "685-725 Commonwealth Avenue"], "CFA" : ["College of Fine Arts", "855 Commonwealth Avenue"],
                      "CDS" : ["Computing & Data Sciences Building", "665 Commonwealth Ave"], "CGS" : ["College of General Studies", "871 Commonwealth Avenue"], "CLN" : ["Clinical Psychology", "900 Commonwealth Avenue"], "COM" : ["College of Communication", "640 Commonwealth Avenue"], 
                      "CRW" : ["DeWolfe Crew Boathouse", "619 Memorial Drive"], "CSE" : ["Case Physical Education Center", "285 Babcock Street"], "EGL" : ["English Faculty Offices", "236 Bay State Road"], "EIB" : ["Editorial Institute Building", "143 Bay State Road"], 
                      "EIL" : ["Eilberg Lounge (Case Center)", "285 Babcock Street"], "EMA" : ["Engineering Manufacturing Annex", "730 Commonwealth Avenue"], "EMB" : ["Engineering Manufacturing Building", "15 St. Mary's Street"], "ENG" : ["College of Engineering", "110-112 Cummington Mall"], 
                      "EOP" : ["Center for English Language & Orientation Programs", "890 Commonwealth Avenue"], "EPC": ["Engineering Product Innovation Center", "750 Commonwealth Avenue"], "ERA" : ["Engineering Research Annex", "48 Cummington Mall"], 
                      "ERB" : ["Engineering Research Building", "44 Cummington Mall"], "FAB" : ["Fenway Activities Building", "180 The Riverway"], "FCB" : ["Fenway Classroom Building", "25 Pilgrim Road"], "FCC" : ["Fenway Campus Center", "150 The Riverway"], 
                      "FLR" : ["Fuller Building", "808 Commonwealth Avenue"], "FOB" : ["Faculty Office Building (Alden Hall)", "704 Commonwealth Avenue"], "FRC" : ["Fitness & Recreation Center", "915 Commonwealth Avenue"], "GDP" : ["Global Development Policy Center", "53 Bay State"], 
                      "GSU" : ["George Sherman Student Union", "775 Commonwealth Avenue"], "HAR" : ["Rafik B. Hariri Building, Questrom School of Business", "595 Commonwealth Avenue"], "HAW" : ["Hawes Building", "43 Hawes Street, Brookline"], 
                      "HIS" : ["History and American Studies", "226 Bay State Road"], "IEC" : ["International Education Center", "888 Commonwealth Avenue"], "IRB" : ["International Relations Building", "154 Bay State Road"], "IRC" : ["International Relations Center", "152 Bay State Road"], 
                      "JSC" : ["Judaic Studies Center", "147 Bay State Road"], "KCB" : ["Kenmore Classroom Building", "565 Commonwealth Avenue"], "KHC" : ["Kilachand Honors College", "91 Bay State Road"], "LAW" : ["Law School Building", "765 Commonwealth Avenue"], 
                      "LEV" : ["Leventhal Center", "233 Bay State Road"], "LNG" : ["Romance Studies, Modern Foreign Languages & Comparative Literature", "718 Commonwealth Avenue"], "LSE" : ["Life Science & Engineering Building", "24 Cummington Mall"], 
                      "MCH" : ["Marsh Chapel", "735 Commonwealth Avenue"], "MCS": ["Math & Computer Science", "111 Cummington Mall"], "MET" : ["Metropolitan College", "1010 Commonwealth Avenue"], "MOR" : ["Morse Auditorium", "602 Commonwealth Avenue"], 
                      "MUG" : ["Mugar Memorial Library", "771 Commonwealth Avenue"], "PHO" : ["Photonics Building", "6-8 St. Mary's Street"], "PLS" : ["Anthropology, Philosophy, Political Science, African Studies Center", "232 Bay State Road"], "PRB" : ["Physics Research Building", "3 Cummington Mall"], 
                      "PSY" : ["Psychology", "64-72-86 Cummington Mall"], "PTH" : ["Playwrights' Theatre", "949 Commonwealth Avenue"], "REL" : ["CAS Religion", "145 Bay State Road"], "SAC" : ["Sargent Activities Center", "1 University Road"], "SAL" : ["Sailing Docks", "Charles River Behind BU Bridge"], 
                      "SAR" : ["Sargent College", "635 Commonwealth Avenue"], "SCI" : ["Metcalf Science Center", "590-596 Commonwealth Avenue"], "SHA" : ["School of Hospitality Administration", "928 Commonwealth Avenue"], "SLB" : ["Science Library Building", "30-38 Cummington Mall"], 
                      "SOC" : ["Sociology", "96-100 Cummington Mall"], "SSW" : ["School of Social Work", "264-270 Bay State Road"], "STH" : ["School of Theology", "745-755 Commonwealth Avenue"], "STO" : ["Stone Science Building", "675 Commonwealth Avenue"], "THA" : ["Joan & Edgar Booth Theatre", "820 Commonwealth Avenue"], 
                      "TTC" : ["Track & Tennis Center", "100 Ashford Street"], "WEA" : ["Wheelock College of Education & Human Development Annex", "621 Commonwealth Avenue"], "WED" : ["Wheelock College of Education & Human Development", "2 Silber Way"], 
                      "YAW" : ["Yawkey Center for Student Services", "100 Bay State Road"]}
    
    for room_abrev in room_directory:
        if p_message == room_abrev:
            print("That is the {building} located at {address}.".format(building = room_directory[room_abrev][0], address = room_directory[room_abrev][1]))
            return "That is the {building} located at {address}.".format(building = room_directory[room_abrev][0], address = room_directory[room_abrev][1])
        
    return "Room not found!"

    
 	 	
