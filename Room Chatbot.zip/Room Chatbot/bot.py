#Import Discord Package
import discord
import responses

async def send_message(message, user_message):
    try:
        response = responses.handle_response(user_message)
        await message.channel.send(response)
    except Exception as e:
        print(e)  

def run_discord_bot():
    #Bot Discord Token 
    TOKEN = 'MTEzMDg4OTkyMTE1NTA1MTY1MQ.GjSbDP.6ThwFDD3ERUjLHoSEkDfv9zX9IAX0Y6jA6Ef2s'
    #Client (the bot)
    intents = discord.Intents.default()  
    intents.message_content = True
    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f'{client.user} is now running!')
    
    @client.event
    async def on_message(message):
        #Ignore own messages
        if message.author == client.user:
            return
        #Setting Variables 
        username = str(message.author)
        user_message = str(message.content)
        channel =  str(message.channel)

        #Debugging/Chat log
        print(f"{username} said: '{user_message}' ({channel})")

        p_message = user_message.upper()
        print(p_message)

        if p_message[0:5] == "?ROOM":
            user_message = user_message[6:]
            await send_message(message, user_message)
            print(user_message)
    

    client.run(TOKEN)

    